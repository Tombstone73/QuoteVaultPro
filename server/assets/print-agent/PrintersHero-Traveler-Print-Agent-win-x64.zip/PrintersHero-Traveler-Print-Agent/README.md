# PrintersHero Windows Print Agent

Version 1.0.30

This is the shop-side, outbound-only agent for Traveler, Pickup Traveler, Quick
Note, Packing Slip, Shipment Manifest, Package Ticket, and UPS Label jobs. It runs
in the logged-in Windows session because Edge WebView2 and Windows printer
drivers must use that session. It never listens on the LAN and the cloud never
opens a connection to the workstation.

The agent claims a tenant-scoped job, loads the existing PrintersHero Traveler
page with that claimed-job credential, waits for the React Traveler to finish
rendering, and asks Windows to spool it to the mapped queue. `submitted` means
Windows accepted the spool request; it cannot guarantee paper physically left
the Epson.

The agent keeps a direct, outbound Supabase Realtime subscription using its
paired capability topic. When PrintersHero durably queues a Traveler, it sends
a data-free `queue_changed` wake signal. The agent then checks its authenticated
queue, claims, renders, and prints serially until the active queue is empty.
There is no separate recurring job-queue polling loop. An authenticated heartbeat
runs every 30 seconds and announces compatible queued work, with a 20-second
HTTP timeout. It reports the executable version, inventory, and bounded
connection state. A pending flag signals the existing scheduler; the heartbeat
itself cannot enqueue or repeat a print. Channel rejoins
(including a rejoin without socket reopening) trigger one serialized catch-up.
The SDK may reconnect normally; an unavailable channel is rebuilt after 60
seconds, with local backoff capped at 30 seconds. Initial connect/join waits
are bounded. Claimed and submitted jobs are never retried by reconnect.

Version 1.0.30 adds a system tray icon with connection state, last confirmed
API heartbeat, errors, and **Restart Bridge Service**. Restart uses the same
local scheduled-task controller and is refused while this agent is draining
print jobs. If the icon is absent, run the existing local restart command below.
There is no HTTP/LAN restart listener. Printer Settings explains this local
recovery instead of pretending to restart a Windows process remotely.

Shipping documents require agent 1.0.25 or newer and an explicitly enabled
document capability on the printer profile. They use the same durable queue,
paired agent, and configured Windows printer, not a separate service. The source
is frozen at enqueue; only the assigned agent can read it after claiming the job.
The opaque shipping shell waits for pages, fonts, and images and binds readiness
to both the job id and document type. Unsupported types fail instead of printing
a Traveler. A full Package Ticket set is one spool job with multiple pages.

UPS 4 x 6 inch GIF labels require agent 1.0.26 or newer, a shipping-label
printer profile, and a Windows printer driver configured for matching label
stock. The label is printed as a raster image through the existing queue;
the agent does not send ZPL to devices that may not support it.

Source milestone: the installer/package must be rebuilt from these sources
before distributing 1.0.30. An existing downloadable ZIP is not updated by a
source-only change. Verify the rebuilt executable reports 1.0.30 before release.

## Shop workstation setup

No Visual Studio, .NET runtime installation, source editing, or manual task
creation is required.

1. Download and extract the `PrintersHero-Traveler-Print-Agent-win-x64.zip`
   release package to a stable local folder.
2. In PrintersHero Settings, create a Local Bridge / Print Agent pairing token.
   Copy it; it is shown only once.
3. Double-click `setup-agent.cmd` (or right-click `setup-agent.ps1` and choose
   **Run with PowerShell**).
4. Approve the one-time Windows administrator prompt for the signed-in Windows
   user. It creates the startup task; no manual Task Scheduler work is needed.
   If it fails, the Administrator setup window stays open and shows the exact
   error.
5. If needed, accept the prompt to open the official Microsoft WebView2
   Runtime installer page. Install it, then run setup again.
6. Choose the existing initial Traveler Windows queue from the numbered list,
   then paste the pairing token when prompted. USB and IP-installed queues
   work the same way. The production API defaults to
   `https://api.printershero.com`; do not substitute the web-app URL.
7. Setup registers the initial Traveler queue for the paired agent, securely receives the
   Supabase project URL and non-secret publishable subscription key, installs
   and starts the per-user logon task, and shows an `[OK]` checklist. It never
   receives a Supabase service-role key. The pairing token is never shown again
   or written to agent logs.
8. On the Printers page, map each reported Windows queue to a profile and
   select its document purpose and media. An updated paired agent can serve
   Epson, Zebra, and supported office queues concurrently. Run **Test Print**
   for each profile and confirm paper output at the physical printer.

The pairing token identifies this installation, not a printer. Reuse the
installed token when adding queues on the same workstation. After installing
a new Windows queue, restart the agent so its reported inventory refreshes.
The existing task and environment variable name retain "Traveler" for upgrade
compatibility; neither limits the updated agent to that printer.

The release is a **self-contained win-x64** build. It includes the required
.NET runtime files; WebView2 remains the only workstation prerequisite.

### Diagnostics and removal

```powershell
.\setup-agent.ps1 -Check
.\setup-agent.ps1 -Uninstall
.\setup-agent.ps1 -Uninstall -RemoveConfiguration
```

`-Check` verifies WebView2, the selected local queue, agent executable,
configuration presence, startup task, process, and an explicit authenticated
PrintersHero diagnostic. It never prints the pairing token. Uninstall does not revoke the
server-side pairing credential.

The logon task is intentional instead of a Windows Session 0 service: the
Epson driver and WebView2 print integration must run in the logged-in user's
session. The underlying task script still supports `install`, `start`, `stop`,
`restart`, `status`, and `uninstall` for diagnostics.

## Development and release build

For development, normal `dotnet build` remains available. To create the shop
package on a build machine with the .NET 8 SDK:

```powershell
.\scripts\build-release.ps1
```

This runs the `Shop-win-x64` publish profile with `SelfContained=true`, writes
the distributable folder to `release\PrintersHero-Traveler-Print-Agent\`, and
creates `release\PrintersHero-Traveler-Print-Agent-win-x64.zip`. The package
contains no tokens or machine-specific printer names.

## Troubleshooting

- `Mapped Windows printer is unavailable`: the local Epson queue does not
  exist or its name differs from the queue selected during setup.
- A claimed job that is not acknowledged remains claimed rather than being
  retried automatically. This intentionally avoids a duplicate physical
  Traveler after a crash; make a new explicit Print Traveler request if needed.
- Ensure the API URL has no path suffix and uses HTTPS in production.
- Local agent logs are at `%LOCALAPPDATA%\PrintersHero\print-agent.log`; they
  contain job ids and printer names, never the bridge credential or document.
- `trailingFeedMm` is additional space after the standard 38.1 mm / 1.5 in
  tear-off spacer. The log reports both the additional and effective feed
  immediately before Windows receives the print request.
- Do not copy the bridge token into tickets, logs, or source control. Revoke
  and recreate the agent in Settings if it is exposed.

## Shipping label orientation

Original UPS GIF bytes, SHA, shipment, and tracking identity remain unchanged.
Original evidence downloads and all-label ZIP archives still return those bytes.
For supported 4x6 GIF geometry, preview, PDF download, and direct printing use
one server-side lossless PNG derivative: landscape pixels turn clockwise once;
portrait pixels do not turn. The PDF has a 288x432 pt MediaBox/CropBox and no
page rotation. Unexpected aspect ratios/animated files fail visibly instead of
being cropped or stretched. Review the original evidence for unsupported stock.

A Zebra 450 uses its installed Windows driver queue, assigned to a shipping-label
profile with UPS Label enabled and 4x6 media. No ZPL capability is assumed.
The Epson queue remains independently mapped to Traveler/Quick Note media.
Physical barcode scanning, stock alignment, actual queue names, and disconnect/
restart while idle still require shop verification; successful spool submission
is not physical print confirmation.


1.0.30 uses the existing authenticated 30-second heartbeat to discover queued jobs
when a Realtime notification was missed. Only compatible jobs still queued for this
agent are announced. The same STA scheduler and atomic claim remain authoritative;
claimed, rendering, failed and submitted jobs are never automatically requeued.
A Windows-accepted job whose acknowledgement fails remains uncertain on the server
and needs operator review. It must not be treated as a safe failure/retry.
The tray uses the packaged Printers Hero icon. Install the new package deliberately;
no running installation is updated or restarted by repository builds.

The Shipping Labels Test Print is a true 4x6-inch page with a thin border inset
1/8 inch, four labeled corner marks, orientation/dimension labels, printer
identity and a Code 128 TEST barcode. It does not purchase or reprint a UPS label.
The 1.0.30 server renderer also recognizes legacy 7x4 UPS GIF canvases, removing
only verified white trailing padding. Nonwhite content is never cropped to force
4x6; unsupported geometry still fails clearly. Original carrier bytes stay intact.
